package com.capgemini.lesson6.useoffinal;

/*
 * Below code will not work 
 * as class Base is declared as final
 */
public class Derived extends Base {

}
